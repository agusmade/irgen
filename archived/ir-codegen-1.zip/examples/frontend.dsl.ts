import { frontend } from "../src/dsl/frontend-runtime.js";

frontend("DemoFrontend", (f) => {
  f.component("ProductList", (c) => {
    c.entityRef = "Product";
  });

  f.page("Products", { path: "/products" }, (p) => {
    p.component("ProductList");
  });
});
