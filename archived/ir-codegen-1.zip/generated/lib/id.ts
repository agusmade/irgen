// Generated: single point of truth for ID generation
import { v4 as uuidv4 } from "uuid";
export function newId(): string {
  return uuidv4();
}

