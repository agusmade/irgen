import React from "react";
import { useEffect, useState } from "react";
import { ProductList } from "../components/productlist";
export function ProductsPage() {
  return (
    <div>
      <ProductList />
    </div>
  );
}
