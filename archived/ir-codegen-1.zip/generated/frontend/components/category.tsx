import React from "react";
import { useEffect, useState } from "react";
import { CategoryService } from "../../services/category.service";
import { Category } from "../../lib/models";
export function CategoryComponent(props: { service: any }) {
  const service = props.service;
  const [items, setItems] = useState<Category[]>([]);
  useEffect(() => {
    setItems((service as any)["listCategories"]());
  }, [service]);
  function handleCreate(data: Category) {
    (service as any)["createCategory"](data);
    setItems((service as any)["listCategories"]?.() ?? []);
  }

  function handleUpdate(id: string, data: Partial<Category>) {
    (service as any)["updateCategory"](id, data);
    setItems((service as any)["listCategories"]?.() ?? []);
  }

  function handleRemove(id: string) {
    (service as any)["removeCategory"](id);
    setItems((service as any)["listCategories"]?.() ?? []);
  }

  return (
    <div className="p-4 space-y-4">
      <h3>Category</h3>
      <ul>
        {items.map(i => <li key={i.id}>{JSON.stringify(i)}</li>)}

      </ul>
    </div>
  );
}
