import React from "react";
import { useEffect, useState } from "react";
import { ProductService } from "../../services/product.service";
import { Product } from "../../lib/models";
export function ProductComponent(props: { service: any }) {
  const service = props.service;
  const [items, setItems] = useState<Product[]>([]);
  useEffect(() => {
    setItems((service as any)["listProducts"]());
  }, [service]);
  function handleCreate(data: Product) {
    (service as any)["createProduct"](data);
    setItems((service as any)["listProducts"]?.() ?? []);
  }

  function handleUpdate(id: string, data: Partial<Product>) {
    (service as any)["updateProduct"](id, data);
    setItems((service as any)["listProducts"]?.() ?? []);
  }

  function handleRemove(id: string) {
    (service as any)["removeProduct"](id);
    setItems((service as any)["listProducts"]?.() ?? []);
  }

  return (
    <div className="p-4 space-y-4">
      <h3>Product</h3>
      <ul>
        {items.map(i => <li key={i.id}>{JSON.stringify(i)}</li>)}

      </ul>
    </div>
  );
}
