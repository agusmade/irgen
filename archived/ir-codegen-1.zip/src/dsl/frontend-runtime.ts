import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { DeclFrontendApp, DeclComponent, DeclPage, DeclFrontendAppSchema } from "../ir/frontend.js";

let CURRENT_FRONTEND: DeclFrontendApp | null = null;

function assert(cond: unknown, msg: string): asserts cond {
  if (!cond) throw new Error(msg);
}

export function frontend(name: string, fn: (a: { page: (name: string, opts: { path: string }, cb?: (p: any) => void) => void; component: (name: string, cb?: (c: any) => void) => void; }) => void) {
  assert(typeof name === "string" && name.length > 0, "frontend(name) harus string");
  assert(typeof fn === "function", "frontend(..., fn) fn harus function");

  CURRENT_FRONTEND = { type: "frontend", name, pages: [], components: [] };

  fn({
    page(pName, opts, cb) {
      assert(CURRENT_FRONTEND, "page() harus di dalam frontend()");
      const page: DeclPage = { type: "page", name: pName, path: opts.path, components: [] } as any;
      if (typeof cb === "function") {
        cb({ component(cName, cCb) { const comp: DeclComponent = { type: "component", name: cName }; if (typeof cCb === "function") cCb(comp); page.components.push(comp); } });
      }
      CURRENT_FRONTEND.pages.push(page);
    },
    component(name, cb) {
      assert(CURRENT_FRONTEND, "component() harus di dalam frontend()");
      const comp: DeclComponent = { type: "component", name } as any;
      if (typeof cb === "function") cb(comp);
      CURRENT_FRONTEND.components.push(comp);
    },
  });

  const parsed = DeclFrontendAppSchema.parse(CURRENT_FRONTEND);
  CURRENT_FRONTEND = parsed;
  return parsed;
}

export async function loadFrontendDsl(entry: string): Promise<DeclFrontendApp> {
  const abs = path.resolve(process.cwd(), entry);
  const url = pathToFileURL(abs).href;

  // reset
  CURRENT_FRONTEND = null;

  await import(url);

  if (!CURRENT_FRONTEND) throw new Error(`Frontend DSL did not call frontend(...)`);
  const parsed = DeclFrontendAppSchema.parse(CURRENT_FRONTEND);
  return parsed;
}
