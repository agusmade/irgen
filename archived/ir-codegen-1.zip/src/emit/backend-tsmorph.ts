import path from "node:path";
import fs from "node:fs";
import { Project, QuoteKind, IndentationText, ScriptTarget, Scope } from "ts-morph";
import type { BackendIR, BackendEntity } from "../ir/types.js";
import { emitFrontend } from "./frontend-react.js";

function ensureDir(p: string) {
  fs.mkdirSync(p, { recursive: true });
}

function cleanDir(p: string) {
  if (!fs.existsSync(p)) return;
  fs.rmSync(p, { recursive: true, force: true });
}

export function emitBackend(ir: BackendIR, outDir: string) {
  cleanDir(outDir);
  ensureDir(outDir);
  ensureDir(path.join(outDir, "lib"));
  ensureDir(path.join(outDir, "services"));
  ensureDir(path.join(outDir, "controllers"));

  const project = new Project({
    useInMemoryFileSystem: false,
    manipulationSettings: {
      quoteKind: QuoteKind.Double,
      indentationText: IndentationText.TwoSpaces,
    },
    compilerOptions: { target: ScriptTarget.ES2022 },
  });

  emitIdAdapter(project, outDir);
  emitModels(project, outDir, ir.entities);

  for (const entity of ir.entities) {
    emitService(project, outDir, entity);
    emitController(project, outDir, entity);
  }

  // frontend emitter (React) — optional features controlled by `ir.policies.frontend`
  if (ir.policies?.frontend?.react) {
    // call emitFrontend synchronously (module imported above)
    try {
      emitFrontend(project, outDir, ir);
    } catch (err) {
      // ignore frontend emit failures to keep generator resilient
    }
  }

  project.saveSync();
}

function emitIdAdapter(project: Project, outDir: string) {
  const sf = project.createSourceFile(path.join(outDir, "lib", "id.ts"), "", { overwrite: true });

  sf.addStatements([
    `// Generated: single point of truth for ID generation`,
    `import { v4 as uuidv4 } from "uuid";`,
    ``,
    `export function newId(): string {`,
    `  return uuidv4();`,
    `}`,
    ``,
  ]);
}

function emitModels(project: Project, outDir: string, entities: BackendEntity[]) {
  const sf = project.createSourceFile(path.join(outDir, "lib", "models.ts"), "", { overwrite: true });

  sf.addStatements([`// Generated: model interfaces`]);

  for (const e of entities) {
    if (e.model && Object.keys(e.model).length > 0) {
      const iface = sf.addInterface({
        name: e.name,
        isExported: true,
      });

      for (const [k, t] of Object.entries(e.model)) {
        iface.addProperty({ name: k, type: t });
      }
    } else {
      sf.addStatements([`export type ${e.name} = Record<string, any>;`]);
    }

    sf.addStatements(["", ""]);
  }
}

function emitController(project: Project, outDir: string, entity: BackendEntity) {
  const fileName = `${entity.name.toLowerCase()}.controller.ts`;
  const sf = project.createSourceFile(path.join(outDir, "controllers", fileName), "", { overwrite: true });

  sf.addImportDeclaration({
    moduleSpecifier: `../services/${entity.name.toLowerCase()}.service`,
    namedImports: [`${entity.name}Service`],
  });

  sf.addImportDeclaration({
    moduleSpecifier: `../lib/models`,
    namedImports: [entity.name],
  });

  const className = `${entity.name}Controller`;

  const cls = sf.addClass({ name: className, isExported: true });

  // private service instance
  cls.addProperty({ name: "service", scope: Scope.Private, type: `${entity.name}Service`, initializer: `new ${entity.name}Service()` });

  for (const op of entity.operations) {
    if (op.kind === "CREATE") {
      cls.addMethod({
        name: op.methodName,
        parameters: [{ name: "payload", type: entity.name }],
        returnType: entity.name,
        statements: [`return this.service.${op.methodName}(payload);`],
      });
    } else if (op.kind === "GET") {
      cls.addMethod({
        name: op.methodName,
        parameters: [{ name: "id", type: "string" }],
        returnType: `${entity.name} | null`,
        statements: [`return this.service.${op.methodName}(id);`],
      });
    } else if (op.kind === "LIST") {
      cls.addMethod({
        name: op.methodName,
        parameters: [],
        returnType: `${entity.name}[]`,
        statements: [`return this.service.${op.methodName}();`],
      });
    } else if (op.kind === "UPDATE") {
      cls.addMethod({
        name: op.methodName,
        parameters: [
          { name: "id", type: "string" },
          { name: "payload", type: `Partial<${entity.name}>` },
        ],
        returnType: `${entity.name} | null`,
        statements: [`return this.service.${op.methodName}(id, payload);`],
      });
    } else if (op.kind === "REMOVE") {
      cls.addMethod({
        name: op.methodName,
        parameters: [{ name: "id", type: "string" }],
        returnType: "boolean",
        statements: [`return this.service.${op.methodName}(id);`],
      });
    }
  }
}

function emitService(project: Project, outDir: string, entity: BackendEntity) {
  const fileName = `${entity.name.toLowerCase()}.service.ts`;
  const sf = project.createSourceFile(path.join(outDir, "services", fileName), "", { overwrite: true });

  sf.addImportDeclaration({
    moduleSpecifier: "../lib/id",
    namedImports: ["newId"],
  });

  const className = `${entity.name}Service`;

  const cls = sf.addClass({
    name: className,
    isExported: true,
  });

  // contoh: in-memory store minimal
  cls.addProperty({
    name: "store",
    type: `Map<string, any>`,
    initializer: "new Map()",
    scope: Scope.Private,
  });

  // import model type if available
  if (entity.model) {
    sf.addImportDeclaration({ moduleSpecifier: "../lib/models", namedImports: [entity.name] });
  }

  for (const op of entity.operations) {
    if (op.kind === "CREATE") {
      cls.addMethod({
        name: op.methodName,
        parameters: [{ name: "data", type: entity.model ? entity.name : "Record<string, any>" }],
        returnType: entity.model ? entity.name : "any",
        statements: [
          `const id = newId();`,
          `const row = { ...data, id };`,
          `this.store.set(id, row);`,
          `return row;`,
        ],
      });
    } else if (op.kind === "GET") {
      cls.addMethod({
        name: op.methodName,
        parameters: [{ name: "id", type: "string" }],
        returnType: entity.model ? `${entity.name} | null` : "any | null",
        statements: [
          `return this.store.get(id) ?? null;`,
        ],
      });
    } else if (op.kind === "LIST") {
      cls.addMethod({
        name: op.methodName,
        parameters: [],
        returnType: entity.model ? `${entity.name}[]` : "any[]",
        statements: [
          `return Array.from(this.store.values());`,
        ],
      });
    } else if (op.kind === "UPDATE") {
      cls.addMethod({
        name: op.methodName,
        parameters: [
          { name: "id", type: "string" },
          { name: "data", type: entity.model ? `Partial<${entity.name}>` : "Record<string, any>" },
        ],
        returnType: entity.model ? `${entity.name} | null` : "any | null",
        statements: [
          `const existing = this.store.get(id);`,
          `if (!existing) return null;`,
          `const updated = { ...existing, ...data };`,
          `this.store.set(id, updated);`,
          `return updated;`,
        ],
      });
    } else if (op.kind === "REMOVE") {
      cls.addMethod({
        name: op.methodName,
        parameters: [{ name: "id", type: "string" }],
        returnType: "boolean",
        statements: [
          `return this.store.delete(id);`,
        ],
      });
    }
  }
}
