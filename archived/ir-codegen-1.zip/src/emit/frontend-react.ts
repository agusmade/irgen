import path from "node:path";
import fs from "node:fs";
import { Project, QuoteKind, IndentationText, ScriptTarget } from "ts-morph";
import type { FrontendIR, FrontendPage, FrontendComponent } from "../ir/frontend.js";

function ensureDir(p: string) {
  fs.mkdirSync(p, { recursive: true });
}

export function emitFrontend(project: Project, outDir: string, ir: FrontendIR) {
  const frontendDir = path.join(outDir, "frontend");
  ensureDir(frontendDir);

  // index file
  const idx = project.createSourceFile(path.join(frontendDir, "index.tsx"), "", { overwrite: true });
  idx.addStatements([
    `// Generated frontend entrypoints (React components/pages).`,
    `export * from "./pages";`,
    `export * from "./components";`,
  ]);

  // pages barrel
  const pagesBarrel = project.createSourceFile(path.join(frontendDir, "pages.ts"), "", { overwrite: true });
  pagesBarrel.addStatements([`// Re-exports for generated pages`]);

  // components barrel
  const compsBarrel = project.createSourceFile(path.join(frontendDir, "components.ts"), "", { overwrite: true });
  compsBarrel.addStatements([`// Re-exports for generated components`]);

  for (const p of ir.pages) {
    emitPage(project, frontendDir, p);
    pagesBarrel.addStatements([`export * from "./pages/${p.name.toLowerCase()}";`]);
  }

  for (const c of ir.components) {
    emitComponent(project, frontendDir, c);
    compsBarrel.addStatements([`export * from "./components/${c.name.toLowerCase()}";`]);
  }
}

function emitPage(project: Project, frontendDir: string, page: FrontendPage) {
  const dir = path.join(frontendDir, "pages");
  project.createDirectory(dir);
  const filePath = path.join(dir, `${page.name.toLowerCase()}.tsx`);
  const sf = project.createSourceFile(filePath, "", { overwrite: true });

  sf.addImportDeclaration({ moduleSpecifier: "react", defaultImport: "React" });
  sf.addImportDeclaration({ moduleSpecifier: "react", namedImports: ["useEffect", "useState"] });

  const compImports: string[] = [];
  for (const c of page.components) {
    compImports.push(`import { ${c.name} } from "../components/${c.name.toLowerCase()}";`);
  }

  sf.addStatements(compImports);

  const compName = `${page.name}Page`;
  const statements: string[] = [];
  statements.push(`export function ${compName}() {`);
  statements.push(`  return (`);
  statements.push(`    <div>`);

  for (const c of page.components) {
    statements.push(`      <${c.name} />`);
  }

  statements.push(`    </div>`);
  statements.push(`  );`);
  statements.push(`}`);

  sf.addStatements(statements);
}

function emitComponent(project: Project, frontendDir: string, component: FrontendComponent) {
  const dir = path.join(frontendDir, "components");
  project.createDirectory(dir);
  const filePath = path.join(dir, `${component.name.toLowerCase()}.tsx`);
  const sf = project.createSourceFile(filePath, "", { overwrite: true });

  sf.addImportDeclaration({ moduleSpecifier: "react", defaultImport: "React" });
  sf.addImportDeclaration({ moduleSpecifier: "react", namedImports: ["useEffect", "useState"] });

  const compName = `${component.name}`;
  const statements: string[] = [];
  statements.push(`export function ${compName}() {`);
  statements.push(`  return (`);
  statements.push(`    <div>`);
  if (component.entityRef) {
    statements.push(`      <div>Component tied to entity: ${component.entityRef}</div>`);
  } else {
    statements.push(`      <div>Static component: ${component.name}</div>`);
  }

  statements.push(`    </div>`);
  statements.push(`  );`);
  statements.push(`}`);

  sf.addStatements(statements);
}
