import type { DeclApp, BackendIR, BackendOperationKind } from "../ir/types.js";

/**
 * Lowering rules:
 * - Kita paksa konvensi canonical: CREATE/GET/LIST
 * - Method name ditentukan deterministik:
 *   CREATE -> create<Entity>
 *   GET    -> get<Entity>
 *   LIST   -> list<Entity>s (sederhana; nanti bisa pluralization rules)
 */

import { pascal, camel, pluralize } from "../utils/index.js";

function opKind(kind: "create" | "get" | "list" | "update" | "remove"): BackendOperationKind {
  if (kind === "create") return "CREATE";
  if (kind === "get") return "GET";
  if (kind === "update") return "UPDATE";
  if (kind === "remove") return "REMOVE";
  return "LIST";
}

export function declToBackendIR(app: DeclApp): BackendIR {
  return {
    domain: "backend",
    appName: app.name,
    entities: app.entities.map(e => {
      const entityName = pascal(e.name);
      const ops = e.operations.map(op => {
        const K = opKind(op.kind);
        const base =
          K === "CREATE" ? "create" :
          K === "GET" ? "get" :
          K === "UPDATE" ? "update" :
          K === "REMOVE" ? "remove" :
          "list";
        const methodName =
          K === "LIST"
            ? camel(`${base} ${pluralize(entityName)}`)
            : camel(`${base} ${entityName}`);

        return { kind: K, entityName, methodName };
      });

      return {
        name: entityName,
        id: e.id,
        model: e.model ? Object.fromEntries(
          Object.entries(e.model).map(([k, t]) => [k, t])
        ) : undefined,
        operations: ops,
      };
    }),
    policies: { idProvider: "newId", frontend: (app.meta["frontend"] as any) ?? undefined },
  };
}
