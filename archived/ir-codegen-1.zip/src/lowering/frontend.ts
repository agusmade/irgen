import type { DeclFrontendApp } from "../ir/frontend.js";
import type { FrontendIR } from "../ir/frontend.js";
import { pascal } from "../utils/index.js";

export function declToFrontendIR(decl: DeclFrontendApp): FrontendIR {
  return {
    domain: "frontend",
    appName: decl.name,
    pages: decl.pages.map(p => ({ name: p.name, path: p.path, components: p.components.map(c => ({ name: c.name, props: c.props, entityRef: c.entityRef })) })),
    components: decl.components.map(c => ({ name: c.name, props: c.props, entityRef: c.entityRef })),
  };
}
