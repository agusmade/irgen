import path from "node:path";
import path from "node:path";
import { loadDsl } from "./dsl/runtime.js";
import { declToBackendIR } from "./lowering/backend.js";
import { emitBackend } from "./emit/backend-tsmorph.js";
import { loadFrontendDsl } from "./dsl/frontend-runtime.js";
import { declToFrontendIR } from "./lowering/frontend.js";
import { emitFrontend as emitFrontendFromIR } from "./emit/frontend-react.js";

async function main() {
  const modeFlag = process.argv.find(a => a.startsWith("--mode=")) ?? "--mode=backend";
  const mode = modeFlag.split("=")[1];

  // filter args to find entry and outDir while ignoring flags
  const args = process.argv.slice(2).filter(a => !a.startsWith("--mode="));
  const entryArgIndex = args.findIndex(a => a.endsWith(".dsl.ts"));
  const entry = entryArgIndex >= 0 ? args[entryArgIndex] : (mode === "frontend" ? "examples/frontend.dsl.ts" : "examples/app.dsl.ts");
  const outDir = args[entryArgIndex + 1] ?? "generated";

  if (mode === "backend") {
    const decl = await loadDsl(entry);
    const backendIR = declToBackendIR(decl);
    emitBackend(backendIR, path.resolve(process.cwd(), outDir));
  } else if (mode === "frontend") {
    const decl = await loadFrontendDsl(entry);
    const frontendIR = declToFrontendIR(decl);

    // create a ts-morph project so the frontend emitter can create files and save
    const project = new (await import("ts-morph")).Project({
      useInMemoryFileSystem: false,
      manipulationSettings: {
        quoteKind: (await import("ts-morph")).QuoteKind.Double,
        indentationText: (await import("ts-morph")).IndentationText.TwoSpaces,
      },
      compilerOptions: { target: (await import("ts-morph")).ScriptTarget.ES2022 },
    });

    emitFrontendFromIR(project, path.resolve(process.cwd(), outDir), frontendIR);
    project.saveSync();
  } else {
    throw new Error(`unknown mode: ${mode}`);
  }

  console.log("OK");
  console.log("MODE:", mode);
  console.log("DSL :", entry);
  console.log("OUT :", outDir);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
