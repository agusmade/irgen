import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { DeclApp, DeclAppSchema, DeclEntity } from "../ir/types.js";

type EntityBuilder = {
  create(opName?: string): void;
  get(opName?: string): void;
  list(opName?: string): void;
};

type AppBuilder = {
  entity(name: string, fn: (e: EntityBuilder) => void): void;
  meta(key: string, value: unknown): void;
};

let CURRENT: DeclApp | null = null;

function assert(cond: unknown, msg: string): asserts cond {
  if (!cond) throw new Error(msg);
}

function kebab(s: string) {
  return s
    .replace(/([a-z0-9])([A-Z])/g, "$1-$2")
    .replace(/\s+/g, "-")
    .toLowerCase();
}

function defaultEntityId(name: string) {
  return `${kebab(name)}`;
}

export function app(name: string, fn: (a: AppBuilder) => void) {
  assert(typeof name === "string" && name.length > 0, "app(name) harus string");
  assert(typeof fn === "function", "app(..., fn) fn harus function");

  CURRENT = { type: "app", name, entities: [], meta: {} };
  fn({
    entity(entityName, entityFn) {
      assert(CURRENT, "entity() harus di dalam app()");
      const entity: DeclEntity = {
        type: "entity",
        name: entityName,
        id: defaultEntityId(entityName),
        operations: [],
      };

      const eb: EntityBuilder = {
        create(opName) {
          entity.operations.push({ kind: "create", name: opName ?? "create" });
        },
        get(opName) {
          entity.operations.push({ kind: "get", name: opName ?? "get" });
        },
        list(opName) {
          entity.operations.push({ kind: "list", name: opName ?? "list" });
        },
      };

      entityFn(eb);
      CURRENT.entities.push(entity);
    },
    meta(key, value) {
      assert(CURRENT, "meta() harus di dalam app()");
      CURRENT.meta[key] = value;
    },
  });
}

/**
 * Load DSL file (TS/JS) by dynamic import.
 * - Untuk proyek ini: jalankan CLI via `tsx` (default).
 * - Jika ingin `node dist/cli.js`, file DSL tetap bisa TS karena tsconfig include, tapi runtime Node butuh JS/ESM.
 */
export async function loadDsl(entry: string): Promise<DeclApp> {
  const abs = path.resolve(process.cwd(), entry);
  const url = pathToFileURL(abs).href;

  // reset
  CURRENT = null;

  await import(url);

  assert(CURRENT, `DSL tidak memanggil app(...) — file: ${entry}`);

  // validate + normalize
  const parsed = DeclAppSchema.parse(CURRENT);
  return parsed;
}
