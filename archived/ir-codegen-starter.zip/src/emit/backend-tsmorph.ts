import path from "node:path";
import fs from "node:fs";
import { Project, QuoteKind, IndentationText, ScriptTarget } from "ts-morph";
import type { BackendIR, BackendEntity } from "../ir/types.js";

function ensureDir(p: string) {
  fs.mkdirSync(p, { recursive: true });
}

function cleanDir(p: string) {
  if (!fs.existsSync(p)) return;
  fs.rmSync(p, { recursive: true, force: true });
}

export function emitBackend(ir: BackendIR, outDir: string) {
  cleanDir(outDir);
  ensureDir(outDir);
  ensureDir(path.join(outDir, "lib"));
  ensureDir(path.join(outDir, "services"));

  const project = new Project({
    useInMemoryFileSystem: false,
    manipulationSettings: {
      quoteKind: QuoteKind.Double,
      indentationText: IndentationText.TwoSpaces,
    },
    compilerOptions: { target: ScriptTarget.ES2022 },
  });

  emitIdAdapter(project, outDir);
  for (const entity of ir.entities) {
    emitService(project, outDir, entity);
  }

  project.saveSync();
}

function emitIdAdapter(project: Project, outDir: string) {
  const sf = project.createSourceFile(path.join(outDir, "lib", "id.ts"), "", { overwrite: true });

  sf.addStatements([
    `// Generated: single point of truth for ID generation`,
    `import { v4 as uuidv4 } from "uuid";`,
    ``,
    `export function newId(): string {`,
    `  return uuidv4();`,
    `}`,
    ``,
  ]);
}

function emitService(project: Project, outDir: string, entity: BackendEntity) {
  const fileName = `${entity.name.toLowerCase()}.service.ts`;
  const sf = project.createSourceFile(path.join(outDir, "services", fileName), "", { overwrite: true });

  sf.addImportDeclaration({
    moduleSpecifier: "../lib/id",
    namedImports: ["newId"],
  });

  const className = `${entity.name}Service`;

  const cls = sf.addClass({
    name: className,
    isExported: true,
  });

  // contoh: in-memory store minimal
  cls.addProperty({
    name: "store",
    type: `Map<string, any>`,
    initializer: "new Map()",
    scope: "private",
  });

  for (const op of entity.operations) {
    if (op.kind === "CREATE") {
      cls.addMethod({
        name: op.methodName,
        parameters: [{ name: "data", type: "Record<string, any>" }],
        returnType: "any",
        statements: [
          `const id = newId();`,
          `const row = { id, ...data };`,
          `this.store.set(id, row);`,
          `return row;`,
        ],
      });
    } else if (op.kind === "GET") {
      cls.addMethod({
        name: op.methodName,
        parameters: [{ name: "id", type: "string" }],
        returnType: "any | null",
        statements: [
          `return this.store.get(id) ?? null;`,
        ],
      });
    } else if (op.kind === "LIST") {
      cls.addMethod({
        name: op.methodName,
        parameters: [],
        returnType: "any[]",
        statements: [
          `return Array.from(this.store.values());`,
        ],
      });
    }
  }
}
