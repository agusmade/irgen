import path from "node:path";
import { loadDsl } from "./dsl/runtime.js";
import { declToBackendIR } from "./lowering/backend.js";
import { emitBackend } from "./emit/backend-tsmorph.js";

async function main() {
  const entry = process.argv[2] ?? "examples/app.dsl.ts";
  const outDir = process.argv[3] ?? "generated";

  const decl = await loadDsl(entry);
  const backendIR = declToBackendIR(decl);

  emitBackend(backendIR, path.resolve(process.cwd(), outDir));

  console.log("OK");
  console.log("DSL :", entry);
  console.log("OUT :", outDir);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
