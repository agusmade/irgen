import { z } from "zod";

/**
 * DeclIR (hasil tangkapan DSL) — dekat dengan DSL.
 * DomainIR (hasil mapping) — lebih semantik per domain.
 */

export const DeclOperationSchema = z.object({
  kind: z.enum(["create", "get", "list"]),
  name: z.string().min(1),
});

export const DeclEntitySchema = z.object({
  type: z.literal("entity"),
  name: z.string().min(1),
  id: z.string().min(1),
  operations: z.array(DeclOperationSchema).default([]),
});

export const DeclAppSchema = z.object({
  type: z.literal("app"),
  name: z.string().min(1),
  entities: z.array(DeclEntitySchema).default([]),
  meta: z.record(z.any()).default({}),
});

export type DeclOperation = z.infer<typeof DeclOperationSchema>;
export type DeclEntity = z.infer<typeof DeclEntitySchema>;
export type DeclApp = z.infer<typeof DeclAppSchema>;

/** BackendIR minimal (domain-specific) */
export type BackendOperationKind = "CREATE" | "GET" | "LIST";

export interface BackendOperation {
  kind: BackendOperationKind;
  entityName: string;
  methodName: string; // canonical naming hasil rules
}

export interface BackendEntity {
  name: string;
  id: string;
  operations: BackendOperation[];
}

export interface BackendIR {
  domain: "backend";
  appName: string;
  entities: BackendEntity[];
  policies: {
    idProvider: "newId";
  };
}
