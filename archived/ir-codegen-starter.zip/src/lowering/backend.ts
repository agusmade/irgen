import type { DeclApp, BackendIR, BackendOperationKind } from "../ir/types.js";

/**
 * Lowering rules:
 * - Kita paksa konvensi canonical: CREATE/GET/LIST
 * - Method name ditentukan deterministik:
 *   CREATE -> create<Entity>
 *   GET    -> get<Entity>
 *   LIST   -> list<Entity>s (sederhana; nanti bisa pluralization rules)
 */
function pascal(s: string) {
  return s
    .replace(/[_\-\s]+/g, " ")
    .split(" ")
    .filter(Boolean)
    .map(w => w.charAt(0).toUpperCase() + w.slice(1))
    .join("");
}

function camel(s: string) {
  const p = pascal(s);
  return p.charAt(0).toLowerCase() + p.slice(1);
}

function opKind(kind: "create" | "get" | "list"): BackendOperationKind {
  if (kind === "create") return "CREATE";
  if (kind === "get") return "GET";
  return "LIST";
}

export function declToBackendIR(app: DeclApp): BackendIR {
  return {
    domain: "backend",
    appName: app.name,
    entities: app.entities.map(e => {
      const entityName = pascal(e.name);
      const ops = e.operations.map(op => {
        const K = opKind(op.kind);
        const base =
          K === "CREATE" ? "create" :
          K === "GET" ? "get" : "list";
        const methodName =
          K === "LIST"
            ? camel(`${base} ${entityName}s`)
            : camel(`${base} ${entityName}`);

        return { kind: K, entityName, methodName };
      });

      return {
        name: entityName,
        id: e.id,
        operations: ops,
      };
    }),
    policies: { idProvider: "newId" },
  };
}
