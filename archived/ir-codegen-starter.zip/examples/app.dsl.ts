import { app } from "../src/dsl/runtime.js";

app("DemoApp", (a) => {
  a.meta("owner", "Bli Agus");

  a.entity("Product", (e) => {
    e.create();
    e.get();
    e.list();
  });

  a.entity("Category", (e) => {
    e.create();
    e.list();
  });
});
