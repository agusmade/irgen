# IR Codegen Starter (DSL → IR → Lowering → AST Emit)

Proyek kecil untuk memulai tooling seperti yang kita bahas:

- Developer menulis DSL (JS/TS) yang pendek.
- CLI mengeksekusi DSL → menghasilkan DeclIR.
- DeclIR divalidasi → di-map ke DomainIR (contoh: BackendIR).
- Lowering (sederhana dulu) → TargetIR.
- Emitter berbasis AST (ts-morph) → generate source code nyata.

## Quick start

```bash
npm i
npm run gen
```

Output akan muncul di folder `generated/`.

## Struktur
- `src/dsl/` : DSL runtime + IR builder
- `src/ir/`  : types + zod schema untuk IR
- `src/lowering/` : aturan lowering (minimal)
- `src/emit/` : AST emitter (ts-morph)
- `examples/app.dsl.ts` : contoh DSL

## Catatan
- Tool ini sengaja minimal dan deterministik.
- Untuk sekarang, generator hanya menghasilkan:
  - `generated/lib/id.ts` (single point of truth untuk ID)
  - `generated/services/<entity>.service.ts`
